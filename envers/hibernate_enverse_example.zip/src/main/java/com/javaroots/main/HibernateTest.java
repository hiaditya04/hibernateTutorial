package com.javaroots.main;

import org.hibernate.Session;

import com.javaroots.model.User;
import com.javaroots.util.HibernateUtil;

public class HibernateTest {

public static void main(String[] args) {
         
        Session session = HibernateUtil.getSessionFactory().openSession();
 
        //one entry will be created in user table 
        //and audit entry created in user_aud table
        session.beginTransaction();
        
        User u = new User();
        u.setFirstName("Amitabh");
        u.setLastName("bachhan");
        u.setPassword("God");
        
        
        
        session.save(u);
        
        session.getTransaction().commit();
        
        session.beginTransaction();
        User amitabh = (User)session.get(User.class,1l);
        
        amitabh.setFirstName("Abhishek");
        
        session.getTransaction().commit();
        
        
        //no entry in audit table if we change password field
        //because this field is marked as @notAudited
        session.beginTransaction();
        amitabh = (User)session.get(User.class,1l);
        
        amitabh.setPassword("NotGod");
        
        session.getTransaction().commit();
        
		 //get specific revision
        AuditReader reader = AuditReaderFactory.get(HibernateUtil.getSessionFactory().openSession());
        User abhishek = (User) reader.find(User.class, new Long(1), 2);
        System.out.println(abhishek.getFirstName() + " " + abhishek.getLastName());
        
        //get all revision
        
        List<Number> versions = reader.getRevisions(User.class, new Long(1));
        for (Number number : versions) {
          System.out.print(number + " ");
        }
        
       
    }
   
}